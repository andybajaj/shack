package com.gaming.shack.registration.util;

/**
 * The class for the registration util
 * @author shahnawf
 *
 */
public class RegistrationUtil {
	
	/**
	 * The method will be used to get the logged in user
	 * for now returns the static value 
	 * @return
	 */
	public static String getLoggedInUserId() {
		return "Shah" ;
	}
}
