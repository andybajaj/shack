package com.gaming.shack.registration.constants;

/**
 * The constants for the registration service
 * @author shahnawf
 *
 */
public class RegistrationConstants {
	
	public static final int AGE_TILL_MINOR = 17 ;   
}
